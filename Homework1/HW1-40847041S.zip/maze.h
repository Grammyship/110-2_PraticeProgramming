/*
*   maze.h
*
*   made by 40847041S朱自宇
*       A basic header file for 2D maps (or mazes.)
*
*   The maze can:
*   1. set a road symbol
*   2. set an obstacle symbol
*/

#ifndef MAZE_H
#define MAZE_H

#include <stdio.h>
#include <stdlib.h>

class Maze
{
public:
    // setting the maze
    void setHeight( int k ) { height__ = k; }         // height
    void setWidth( int k ) { width__ = k; }           // width
    void setRoad( char k ) { road__ = k; }            // road
    void setObstacle( char k ) { obstacle__ = k; }    // obstacle
    void createMap();   // create space for the map
    void setMap();      // set up map, notice that you must call createMap() before


    // get values
    int getHeight() const { return height__; }
    int getWidth() const { return width__; }
    int getSize() const { return height__*width__; }
    char getRoad() const { return road__; }
    char getObstacle() const { return obstacle__; }
    const char *getMap() const { return map__; }
    void printMap() const;


    // checking
    bool isObstacle( int x, int y ) const { return ( map__[y*width__ + x] == obstacle__ ); }

    // after using, please remember to free the map !!!
    void freeMap() { free(map__); }

private:
    int height__;     // height of the maze
    int width__;      // width of the maze
    char road__;      // character that represent roads
    char obstacle__;  // character that represent obstacles
    char *map__;      // pointer to the maze
};



#endif